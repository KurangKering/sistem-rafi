<?php 
abstract class AbstractAffixMarker
{
	public function __construct($word)
	{
		
	}
}