<?php

namespace KurangKering\GayoStemmer\Stemmer;

interface StemmerInterface
{
    public function stem($text);
}
