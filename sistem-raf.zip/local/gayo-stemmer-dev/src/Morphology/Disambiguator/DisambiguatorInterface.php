<?php

namespace KurangKering\GayoStemmerDev\Morphology\Disambiguator;

interface DisambiguatorInterface
{
    public function disambiguate($word);

}
