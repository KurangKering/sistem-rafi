<?php

namespace KurangKering\GayoStemmerDev\Stemmer;

interface StemmerInterface
{
    public function stem($text);
}
