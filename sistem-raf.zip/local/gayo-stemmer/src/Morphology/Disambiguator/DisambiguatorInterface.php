<?php

namespace KurangKering\GayoStemmer\Morphology\Disambiguator;

interface DisambiguatorInterface
{
    public function disambiguate($word);

}
